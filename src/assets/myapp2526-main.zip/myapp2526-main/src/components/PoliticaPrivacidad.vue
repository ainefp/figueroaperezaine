<template>
    <div class="container my-2">
      <div class="text-center mb-2">
        <h1 class="display-6">Política de Privacidad</h1>
      </div>
  
      <div class="mb-2 text-justify">
        <h2 class="h5">1. Información General</h2>
        <p>
          En cumplimiento con lo establecido en la legislación vigente, se informa que el presente sitio web es propiedad de 
          <strong>Import-Export Teis, S.L.</strong>, con domicilio en <strong>Avenida de Galicia, 36216 Vigo, España, y con CIF B-12345678.
          </strong></p>
        <p>Puede ponerse en contacto con nosotros a través de:</p>
        <ul>
          <li><strong>Teléfono:</strong> +34 986 111 111</li>
          <li><strong>Correo electrónico:</strong> <a href="mailto:info@importexportteis.com">info@importexportteis.com</a></li>
        </ul>
      </div>
  
      <div class="mb-3 text-justify">
        <h2 class="h5">2. Datos que recogemos</h2>
        
          Recopilamos datos personales que usted nos proporciona directamente al utilizar nuestro sitio web o nuestros servicios. Estos datos incluyen:
          <ul>
          <li>Información de contacto: nombre, correo electrónico, teléfono.</li>
          <li>Datos necesarios para realizar transacciones o pedidos: dirección, detalles de pago.</li>
          <li>Información adicional que nos facilite voluntariamente a través de formularios o correos electrónicos.</li>
        </ul>
        
      </div>
  
      <div class="mb-3 text-justify">
        <h2 class="h5">3. Finalidad del tratamiento</h2>
          Tratamos los datos personales para las siguientes finalidades:
          <ul>
            <li>Responder a consultas realizadas a través del sitio web.</li>
            <li>Gestionar pedidos y envíos de productos o servicios.</li>
            <li>Enviar comunicaciones comerciales relacionadas con nuestros productos o servicios, previo consentimiento expreso.</li>
            <li>Cumplir con obligaciones legales.</li>
          </ul>
          
      </div>
  
      <div class="mb-3 text-justify">
        <h2 class="h5">4. Base Jurídica del Tratamiento</h2>
      
          El tratamiento de sus datos personales se basa en:
          <ul>
            <li>Su consentimiento para el envío de formularios de contacto o suscripción.</li>
            <li>La ejecución de un contrato en caso de pedidos.</li>
            <li>El cumplimiento de obligaciones legales.</li>
            </ul>  
          
      </div>
  
      <div class="mb-3 text-justify">
        <h2 class="h5">5. Destinatarios de los datos</h2>
        <p>
          Sus datos personales no serán compartidos con terceros, excepto en los casos necesarios para cumplir con una obligación legal o para ejecutar un contrato (por ejemplo, servicios de transporte).
        </p>
      </div>
      <div class="mb-3 text-justify">
        <h2 class="h5">6. Conservación de los datos</h2>
        <p>
          Conservaremos sus datos personales mientras sean necesarios para cumplir con las finalidades descritas. Cuando ya no sean necesarios, se eliminarán de forma segura.
        </p>
      </div>
      <div class="mb-3 text-justify">
        <h2 class="h5">7. Derechos del usuario</h2>
        Usted tiene derecho a:
          <ul>
            <li>Acceder a sus datos personales.</li>
            <li>Acceder a sus datos personales.</li>
            <li>Rectificar datos inexactos o incompletos.</li>
            <li>Solicitar la supresión de sus datos cuando ya no sean necesarios.</li>
            <li>Limitar el tratamiento de sus datos en determinadas circunstancias.</li>
            <li>Oponerse al tratamiento de sus datos para fines específicos.</li>
            <li>Solicitar la portabilidad de sus datos.</li>
          </ul>
          Para ejercer estos derechos, puede enviar una solicitud a <strong>info@importexportteis.com,</strong> adjuntando una copia de su documento de identidad.
        
      </div>
      <div class="mb-3 text-justify">
        <h2 class="h5">8. Seguridad de los datos</h2>
        <p>
          Implementamos medidas técnicas y organizativas para garantizar la seguridad de sus datos personales y protegerlos frente a accesos no autorizados, pérdida o destrucció        </p>
      </div>
      <div class="mb-3 text-justify">
        <h2 class="h5">9. Cambios dde la Política de Privacidad</h2>
        <p>
          Nos reservamos el derecho a actualizar esta Política de Privacidad en cualquier momento. La fecha de la última modificación se indicará al final del documento.
        </p>     
      </div>
      <div class="mb-3 text-justify">
        <h2 class="h5">10. Cambios dde la Política de Privacidad</h2>
        <p>
          Si tiene alguna pregunta o desea más información sobre nuestra Política de Privacidad, no dude en contactarnos en <strong>info@importexportteis.com</strong>.
          Fecha de última actualización:12/09/2024
        </p>
      </div>
    </div>
  </template>
  
  <style scoped>
  .text-justify {
    text-align: justify;
  }
  </style>
  