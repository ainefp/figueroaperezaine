<template>
    <div class="row">
        <div class="col-12 text-center">
            <h3 class="display-1">404</h3>
            <img src="@/assets/homer-error.png" alt="404 Error" class="mb-4" style="width: 300px; height: auto;" />
            <br></br>
            <h2 class="mb-3">Página No Encontrada</h2>
            <p class="mb-2">Perdona nos hemos equivocado.</p>
            <router-link to="/" class="btn btn-primary rounded-0 border-0 shadow-none">Volver a Inicio</router-link>
        </div>
    </div>
</template>
<script setup>
</script>
<style scoped>
</style>
