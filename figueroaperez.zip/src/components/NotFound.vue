<template>
    <div class="row">
        <div class="col-12 text-center">
            <h1 class="display-1"> 401 </h1>
            <img src="@/assets/homer-error.png" alt="404 Error" class="mb-4" />
            <h2 class="mb-4"> Pçagina no Encontrada </h2>
            <p class="mb-4"> Perdona, nos hemos equivocado </p>
            <router-link to="/" class="btn btn-primary border-0 shadow-none"> Ir a Inicio </router-link>
        </div>
    </div>
</template>
<script setup></script>
<style scoped></style>