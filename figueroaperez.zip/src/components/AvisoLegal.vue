<template>
    <div class="container my-5">
      <div class="text-center mb-4">
        <h1 class="display-6">Aviso Legal</h1>
      </div>
  
      <div class="mb-3 text-justify">
        <h2 class="h5">1. Responsable del Tratamiento</h2>
        <p>
            El responsable del tratamiento de sus datos personales es <strong>Empresa Teis, S.L.,</strong>con domicilio en <strong>Avenida de Galicia, 101 , 45, 36216 Vigo, España, y CIF B-12345678.
            </strong>Puede ponerse en contacto con nosotros a través de:
        </p>
        <ul>
          <li><strong>Teléfono:</strong> +34 986 111 111</li>
          <li><strong>Correo electrónico:</strong> <a href="mailto:info@importexportteis.com">info@empresateis.com</a></li>
        </ul>
      </div>
  
      <div class="mb-3 text-justify">
        <h2 class="h5">2. Condiciones de Uso</h2>
        <p>
          El acceso y uso de este sitio web implica la aceptación de los términos y condiciones establecidos en el presente Aviso Legal. 
          Los usuarios se comprometen a utilizar el sitio web de forma adecuada y lícita.
        </p>
      </div>
  
      <div class="mb-3 text-justify">
        <h2 class="h5">3. Propiedad Intelectual e Industrial</h2>
        <p>
          Todos los contenidos de este sitio web, incluidos textos, imágenes, logotipos, diseños, software, y cualquier otro material, son 
          propiedad de Import-Export Teis, S.L. o de terceros que han autorizado su uso. Queda prohibida su reproducción, distribución, 
          comunicación pública o transformación sin autorización previa y por escrito de los titulares.
        </p>
      </div>
  
      <div class="mb-3 text-justify">
        <h2 class="h5">4. Protección de Datos Personales</h2>
        <p>
          De acuerdo con el Reglamento General de Protección de Datos (RGPD), le informamos de que los datos personales que nos facilite 
          serán tratados por Empresa Teis, S.L. con la finalidad de gestionar las consultas realizadas a través de este sitio web.
          Para más información, consulte nuestra <a href="/politicaprivacidad">Política de Privacidad</a>.
        </p>
      </div>
  
      <div class="mb-3 text-justify">
        <h2 class="h5">5. Exención de Responsabilidad</h2>
        <p>
          Import-Export Teis, S.L. no será responsable de los daños y perjuicios que puedan derivarse del uso incorrecto de los contenidos 
          del sitio web, ni de posibles errores técnicos o interrupciones en el servicio.
        </p>
      </div>
  
      <div class="mb-3 text-justify">
        <h2 class="h5">6. Legislación Aplicable y Jurisdicción</h2>
        <p>
          El presente Aviso Legal se rige por la legislación española. Para cualquier controversia que pueda surgir, ambas partes se someterán 
          a los juzgados y tribunales de Vigo.
        </p>
      </div>
    </div>
  </template>
  
  <style scoped>
    .text-justify {
      text-align: justify;
    }
  </style>
  
